package com.org.rbc.stock.market.stock.market;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
@SpringBootTest
class StockmarketApplicationTests {

	@Test
	void contextLoads() {
	}

}
